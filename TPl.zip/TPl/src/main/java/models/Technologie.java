package models;



public class Technologie {

	private int id;
	private String nom;
	

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public void finalize() throws Throwable {

	}

}


