package models;

public class Directeur extends User {
	private int id;
	
	public Directeur(){

	}

	
}
